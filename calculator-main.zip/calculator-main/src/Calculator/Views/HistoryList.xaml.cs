using System;

using CalculatorApp.ViewModel;
using CalculatorApp.ViewModel.Common;

using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

using MUXC = Microsoft.UI.Xaml.Controls;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace CalculatorApp
{
    [Windows.Foundation.Metadata.WebHostHidden]
    public sealed partial class HistoryList : UserControl
    {
        public HistoryList()
        {
            InitializeComponent();

            HistoryEmpty.FlowDirection = LocalizationSettings.GetInstance().GetFlowDirection();
        }

        public CalculatorApp.ViewModel.HistoryViewModel ViewModel => (CalculatorApp.ViewModel.HistoryViewModel)DataContext;

        // Raised when the last history item is deleted via the context menu, so the
        // hosting page can move focus back to a sensible target (the History button).
        public event EventHandler HistoryEmptied;

        public void ScrollToBottom()
        {
            var historyItems = HistoryListView.Items;
            if (historyItems.Count > 0)
            {
                HistoryListView.ScrollIntoView(historyItems[historyItems.Count - 1]);
            }
        }

        public Windows.UI.Xaml.GridLength RowHeight
        {
            get => (Windows.UI.Xaml.GridLength)GetValue(RowHeightProperty);
            set => SetValue(RowHeightProperty, value);
        }

        // Using a DependencyProperty as the backing store for RowHeight.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RowHeightProperty =
            DependencyProperty.Register(nameof(RowHeight), typeof(Windows.UI.Xaml.GridLength), typeof(HistoryList), new PropertyMetadata(default(Windows.UI.Xaml.GridLength)));

        public static string GetHistoryItemAutomationName(string accExpression, string accResult)
        {
            return $"{accExpression} {accResult}";
        }

        private void ListView_ItemClick(object sender, ItemClickEventArgs e)
        {
            // When the user clears the history list in the overlay view and presses enter, the clickedItem is nullptr
            if (e.ClickedItem is HistoryItemViewModel clickedItem && DataContext is HistoryViewModel historyVM)
            {
                historyVM.ShowItem(clickedItem);
            }
        }
        private void OnCopyMenuItemClicked(object sender, RoutedEventArgs e)
        {
            var listViewItem = HistoryContextMenu.Target;
            if (HistoryListView.ItemFromContainer(listViewItem) is HistoryItemViewModel itemViewModel)
            {
                CopyPasteManager.CopyToClipboard(itemViewModel.Result);
            }
        }
        private void OnDeleteMenuItemClicked(object sender, RoutedEventArgs e)
        {
            var listViewItem = HistoryContextMenu.Target;
            if (HistoryListView.ItemFromContainer(listViewItem) is HistoryItemViewModel itemViewModel)
            {
                var itemsRemainingAfterDelete = HistoryListView.Items.Count - 1;

                if (itemsRemainingAfterDelete > 0)
                {
                    // Capture the position before deleting; the container is torn down on removal.
                    var deletedIndex = HistoryListView.IndexFromContainer(listViewItem);
                    ViewModel.DeleteItem(itemViewModel);

                    var newFocusIndex = Math.Min(deletedIndex, itemsRemainingAfterDelete - 1);
                    var newContainer = HistoryListView.ContainerFromIndex(newFocusIndex) as Control;
                    newContainer?.Focus(FocusState.Programmatic);
                }
                else
                {
                    // Move focus to the fallback target before removing the item, so focus does
                    // not briefly escape (e.g. to the hamburger menu) while the list empties.
                    HistoryEmptied?.Invoke(this, EventArgs.Empty);
                    ViewModel.DeleteItem(itemViewModel);
                }
            }
        }
        private void OnDeleteSwipeInvoked(MUXC.SwipeItem sender, MUXC.SwipeItemInvokedEventArgs e)
        {
            if (e.SwipeControl.DataContext is HistoryItemViewModel swipedItem)
            {
                ViewModel.DeleteItem(swipedItem);
            }
        }
    }
}
